import { base44 } from './base44Client';


export const shareProduct = base44.functions.shareProduct;

export const submitScore = base44.functions.submitScore;

export const finalizeMatch = base44.functions.finalizeMatch;

export const createMatch = base44.functions.createMatch;

export const joinMatch = base44.functions.joinMatch;

export const searchProducts = base44.functions.searchProducts;

