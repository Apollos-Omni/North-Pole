import React from 'react';
import SettingsProfile from './SettingsProfile';

// The root /Settings page now renders the Profile page by default.
export default function Settings() {
  return <SettingsProfile />;
}